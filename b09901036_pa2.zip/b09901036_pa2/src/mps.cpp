#include<iostream>
#include<vector>
#include<cstdlib>
#include<fstream>
using namespace std;
void MIS_CALC(int**   , int   , int ** , int * );
int k_find(int  , int *);
void CHORD_FIND( int , int   , int ** , int * ,int **);
int main(int argc ,char *argv[] )
{

    fstream i_fstg(argv[1], ios::in);
    fstream o_fstg;
    vector<int> i_data;
    int mapsize,chord_result,temp;
    o_fstg.open(argv[2],ios::out);
    while(i_fstg >> temp){
        i_data.push_back(temp);
    }
    mapsize = i_data[0];
    int *i_chord;
    i_chord = new int[i_data.size()/2-1];
    for(int i=1; i<i_data.size()-1; i++)
    {
        i_chord[i_data[i]]=i_data[i];
    }
    int **MIS     = new int *[mapsize] ;
    int **MISCASE = new int *[mapsize] ;
    int **result                       ;
    
    for(int i=0; i<mapsize; ++i)
    {
        MIS[i]      = new int[mapsize];
        MISCASE[i]  = new int[mapsize];
        for(int j=0; j<mapsize; j++){
            
            MISCASE[i][j] = 0;
        }
        for(int j=0; j<mapsize; j++){
            
            if(i>=j) MIS[i][j] = -1;
            else MIS[i][j] = 0;
        }
       
    }//initialization
    
    MIS_CALC(MIS,mapsize,MISCASE,i_chord);
    result = new int*[MIS[0][mapsize]];
    for(int i=0; i<mapsize; i++)        result[i] = new int [2];

    //Free the array of pointers
     for(int i = 0; i < mapsize; ++i) {
        delete[] MIS[i]; 
        delete[] MISCASE[i];  
    }
    
    delete[] MIS;
    delete[] MISCASE;


    return 0;
}
int k_find(int target ,int * i_chord){
    return i_chord[target];
}
void MIS_CALC(int**  MISmatrix, int size , int **MISstate,int *i_chord)
{
    for( int i=0; i<size; i++){
        for( int j=i+1; j<size; j++)
        {
            int key=k_find(j,i_chord);
            if(key<i || key>j) // CASE 1
            {
                    MISmatrix[i][j]   = MISmatrix[i][j-1];
                    MISstate[i][j]    = 1;
            }
            else if(key>=i && key <j) //CASE 2_1 and 2-2 //j,j dont a chord
            {
                    if(MISmatrix[i][j-1]< 1+MISmatrix[i][key-1]+MISmatrix[key+1][j])
                    {
                        MISmatrix[i][j]= 1+MISmatrix[i][key-1]+MISmatrix[key+1][j];
                        MISstate[i][j] = 2 ;
                    }
                    else
                    {
                        MISmatrix[i][j]   = MISmatrix[i][j-1];
                        MISstate[i][j]    = 1;
                    }
            }
            else if(i==key)
            {
                        MISmatrix[i][j]   = MISmatrix[i+1][j-1]+1;
                        MISstate[i][j]    = 3;
            }
        }
    }

}

void CHORD_FIND(  int start_point,int end_point , int **MISstate,int *i_chord,int **result)
{
    int index = 0 ;
    while(end_point-start_point>1)
    {
        int key=k_find(end_point,i_chord);
        if(MISstate[start_point][end_point]==3)
        {
                result[index][0]=key;
                result[index][1]=end_point;
                CHORD_FIND( start_point+1,end_point-1,MISstate,i_chord,result);
        }
        else if(MISstate[start_point][end_point]==2)
        {
            CHORD_FIND( start_point,key-1,MISstate,i_chord,result);
            result[index][0]=key;
            result[index][1]=end_point;
            CHORD_FIND( key,end_point-1,MISstate,i_chord,result);

        }
        else if(MISstate[start_point][end_point]==1)
        {
            end_point=end_point-1;
        }
    }

}

